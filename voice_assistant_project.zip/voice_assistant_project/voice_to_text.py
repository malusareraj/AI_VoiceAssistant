import streamlit as st
import numpy as np
import soundfile as sf
from faster_whisper import WhisperModel
from scipy import signal
import tempfile
import os
from transformers import pipeline
import io
import pyttsx3
import sounddevice as sd  # For live audio input
from io import BytesIO
from pydub import AudioSegment
from pydub.playback import play
import re

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['OMP_NUM_THREADS'] = '1'

# Initialize Whisper model
whisper_model = WhisperModel('base')

# Initialize text summarization and text generation pipelines
summarizer = pipeline("summarization")
text_generator = pipeline("text-generation", model="gpt-2")

def record_audio(duration, sample_rate=16000):
    st.write("Recording...")
    audio = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, dtype='float32')
    sd.wait()  # Wait until recording is finished
    st.write("Recording complete.")
    return audio.flatten(), sample_rate

def voice_to_text(audio, sample_rate):
    # Perform Voice Activity Detection (VAD)
    audio = audio / np.max(np.abs(audio))  # Normalize
    frame_size = 1024
    hop_size = frame_size // 2
    vad = np.abs(audio) > 0.01
    segments = []
    
    for start in range(0, len(audio) - frame_size, hop_size):
        segment = audio[start:start + frame_size]
        if np.any(vad[start:start + frame_size]):
            segments.append(segment)
    
    if len(segments) == 0:
        return "No speech detected"
    
    audio = np.concatenate(segments)
    audio_file = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    sf.write(audio_file.name, audio, sample_rate)
    transcription = whisper_model.transcribe(audio_file.name)
    os.unlink(audio_file.name)
    return transcription['text']

def summarize_with_llm(text):
    summary = summarizer(text, max_length=2, min_length=1, do_sample=False)[0]['summary_text']
    return summary

def generate_llm_response(text):
    response = text_generator(text, max_length=50, num_return_sequences=1)[0]['generated_text']
    return response

def text_to_speech(text, pitch=0, speed=150, voice_gender='male'):
    engine = pyttsx3.init()
    voices = engine.getProperty('voices')
    
    if voice_gender == 'female':
        voice_id = voices[1].id if len(voices) > 1 else voices[0].id
    else:
        voice_id = voices[0].id
    
    engine.setProperty('voice', voice_id)
    engine.setProperty('rate', speed)
    # Adjusting pitch is not directly supported by pyttsx3. This is a workaround.
    engine.setProperty('volume', 1.0 + (pitch / 100.0))

    audio_buffer = BytesIO()
    engine.save_to_file(text, audio_buffer)
    engine.runAndWait()
    audio_buffer.seek(0)

    audio_segment = AudioSegment.from_wav(audio_buffer)
    audio_segment.export("output.wav", format="wav")
    return "output.wav"

def main():
    st.title("Voice-to-Text, LLM Summarization/Response, and Text-to-Speech")

    input_mode = st.selectbox("Select Input Mode", ["Upload File", "Live Voice Recording"])

    vad_threshold = st.slider("VAD Threshold", 0.0, 1.0, 0.5, 0.01)
    pitch = st.slider("Pitch", -50, 50, 0)
    speed = st.slider("Speed", 50, 300, 150)
    voice_gender = st.selectbox("Voice Gender", ["male", "female"])

    if input_mode == "Upload File":
        uploaded_file = st.file_uploader("Choose an audio file", type=["wav", "mp3", "ogg"])

        if uploaded_file is not None:
            st.audio(uploaded_file, format="audio/wav")

            if st.button("Transcribe, Generate Response, and Speak"):
                process_audio_file(uploaded_file, vad_threshold, pitch, speed, voice_gender)

    elif input_mode == "Live Voice Recording":
        duration = st.slider("Recording Duration (seconds)", 1, 60, 5)

        if st.button("Start Recording"):
            audio, sr = record_audio(duration)
            st.audio(audio, format='audio/wav', sample_rate=sr)
            
            if st.button("Transcribe, Generate Response, and Speak Live Recording"):
                process_live_audio(audio, sr, vad_threshold, pitch, speed, voice_gender)

    st.markdown("---")

def process_audio_file(uploaded_file, vad_threshold, pitch, speed, voice_gender):
    with st.spinner("Processing..."):
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(uploaded_file.name)[1]) as tmp_file:
                tmp_file.write(uploaded_file.getvalue())
                tmp_file_path = tmp_file.name

            audio, sr = sf.read(tmp_file_path)
            os.unlink(tmp_file_path)

            transcription = voice_to_text(audio, sr)

            st.subheader("Transcription:")
            st.write(transcription)

            # Use LLM for generating response based on the transcription
            response = generate_llm_response(transcription)

            st.subheader("Generated Response:")
            st.write(response)

            response_audio = text_to_speech(response, pitch=pitch, speed=speed, voice_gender=voice_gender)

            st.subheader("Response Audio:")
            st.audio(response_audio, format="audio/wav")

        except FileNotFoundError:
            st.error("Error: The uploaded file could not be found. Please try uploading again.")
        except sf.SoundFileError:
            st.error("Error: The uploaded file is not a valid audio file. Please upload a WAV, MP3, or OGG file.")
        except Exception as e:
            st.error(f"An unexpected error occurred: {str(e)}")

def process_live_audio(audio, sr, vad_threshold, pitch, speed, voice_gender):
    with st.spinner("Processing..."):
        try:
            transcription = voice_to_text(audio, sr)

            st.subheader("Transcription:")
            st.write(transcription)

            # Use LLM for generating response based on the transcription
            response = generate_llm_response(transcription)

            st.subheader("Generated Response:")
            st.write(response)

            response_audio = text_to_speech(response, pitch=pitch, speed=speed, voice_gender=voice_gender)

            st.subheader("Response Audio:")
            st.audio(response_audio, format="audio/wav")

        except Exception as e:
            st.error(f"An unexpected error occurred: {str(e)}")

if __name__ == "__main__":
    main()
